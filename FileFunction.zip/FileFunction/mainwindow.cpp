#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QMessageBox>
#include <QPushButton>
#include <QFileDialog>
#include <QTextStream>
#include <QLineEdit>
#include <QTextEdit>
#include <QGridLayout>
#include <QDialog>
#include <QLabel>
MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    // ��ʼ���ļ�Ϊδ����״̬
    isUntitled = true;
    // ��ʼ���ļ���Ϊ"δ����.txt"
    curFilePath = tr("Untitled.txt");
    // ��ʼ�����ڱ���Ϊ�ļ���
    setWindowTitle(curFilePath);
    QPushButton *btn =new QPushButton(this);
    QLineEdit *le =new QLineEdit(this);
    //�½�դ�񲼾�
    QGridLayout *layout = new QGridLayout;
    //void QGridLayout::addLayout(QLayout *layout, int row, int column, int rowSpan, int columnSpan, Qt::Alignment alignment = Qt::Alignment())
    //columnSpan and rowSpan both are made up of cells.
    layout->addWidget(btn,0,0,1,1);
    layout->addWidget(le,0,1,1,4);
    layout->addWidget(ui->textEdit,1,0,-1,-1);
    ui->centralWidget->setLayout(layout);
    //add search function
    findDlg = new QDialog(this);
    findDlg->setWindowTitle(tr("Find"));
    findLineEdit = new QLineEdit(findDlg);
    QPushButton *btninFind= new QPushButton(tr("Find Next"), findDlg);
    QVBoxLayout *layoutinFind= new QVBoxLayout(findDlg);
    layoutinFind->addWidget(findLineEdit);
    layoutinFind->addWidget(btninFind);
    connect(btninFind, &QPushButton::clicked, this, &MainWindow::showFindText);
    //show temporary information
//    ui->statusBar->showMessage(tr("Welcome!"),1000);//1000 means 1000ms
    statusLabel = new QLabel;
    statusLabel->setMinimumSize(150, 20); // ���ñ�ǩ��С��С
    statusLabel->setFrameShape(QFrame::WinPanel); // ���ñ�ǩ��״
    statusLabel->setFrameShadow(QFrame::Sunken); // ���ñ�ǩ��Ӱ
    ui->statusBar->addWidget(statusLabel);
    statusLabel->setText(tr("Welcome to pomeas AI research!"));
    //show permanent infomation
    QLabel *permanent = new QLabel;
    permanent->setFrameStyle(QFrame::Box | QFrame::Sunken);
    permanent->setText(

      tr("<a href=\"http://www.pomeas.cn\">www.pomeas.cn</a>"));

    permanent->setTextFormat(Qt::RichText);
    permanent->setOpenExternalLinks(true);
    ui->statusBar->addPermanentWidget(permanent);

}
void MainWindow::newFile()
{
      if(isNeedSave()){
          isUntitled = true;
          // ��ʼ��
          curFilePath = tr("Untitled.txt");
          setWindowTitle(curFilePath);
          ui->textEdit->clear();
          ui->textEdit->setVisible(true);
      }

}
bool MainWindow::isNeedSave()
{
     //if the file has been changed
    if(ui->textEdit->document()->isModified()){
        //Customize a dialog box
        QMessageBox box;
        box.setWindowTitle(tr("Warning!"));
        box.setText(curFilePath+tr("Your file has not been saved yet,do you want to save it?"));
       //QPushButton *QMessageBox::addButton(const QString &text, ButtonRole��ɫ)
        QPushButton *yesBtn =box.addButton(tr("Yes(&Enter)"),QMessageBox::YesRole);
        box.addButton(tr("No(&N)"),QMessageBox::NoRole);
        QPushButton *cancelBtn =box.addButton(tr("Cancel(&Esc)"),QMessageBox::YesRole);
        box.exec();
        if(box.clickedButton()==yesBtn)
            return save();
        else if(box.clickedButton()==cancelBtn)
            return false;
    }
    return true;
}
//void MainWindow::closeEvent(QCloseEvent *event){
//    if(isNeedSave()){
//        event->accept();
//    } else {
//        event->ignore();
//    }
//}
bool MainWindow::save()
{
    if(isUntitled){
        return saveAs();
    }else{
        return saveFile(curFilePath);
    }

}


bool MainWindow::saveAs(){
    QString filename = QFileDialog::getSaveFileName(this,tr("File save as��"),curFilePath);
    if(filename.isEmpty())return false;
    return saveFile(curFilePath);

}

bool MainWindow::saveFile(const QString &fileName)
{
    QFile file(fileName);
    if (!file.open(QFile::WriteOnly|QFile::Text)){
        QMessageBox::warning(this,tr(""),tr("Can not write to %1:/n %2").arg(fileName).arg(file.errorString()));
        return false;
    }
    QTextStream out(&file);
    //���ȴ�
    QApplication::setOverrideCursor(QCursor(Qt::WaitCursor));
    out<<ui->textEdit->toPlainText();
    //���ָ�
    QApplication::restoreOverrideCursor();
    isUntitled =false;
    //��ȡ�ļ�·��
    curFilePath=QFileInfo(fileName).canonicalFilePath();
    setWindowTitle(curFilePath);
    return true;
 //�ú���ִ���������ļ��������������ʹ��һ��QFile�������ָ��Ҫ������ļ���Ȼ��ʹ���ı�д�뷽ʽ����򿪡�
    //�򿪺���ʹ��QTextStream�ı������༭���е�����д�뵽�ļ��С�
}

void MainWindow::on_action_N_triggered()
{
    newFile();
}

void MainWindow::on_action_S_triggered()
{
    save();
}

void MainWindow::on_action_A_triggered()
{
    saveAs();
}
bool MainWindow::loadFile(const QString &fileName)
{
    QFile file(fileName);
    if (!file.open(QFile::ReadOnly|QFile::Text)){
        QMessageBox::warning(this,tr(""),tr("Can not read  %1:/n %2").arg(fileName).arg(file.errorString()));
        return false;
    }
    QTextStream in(&file);
    //���ȴ�
    QApplication::setOverrideCursor(QCursor(Qt::WaitCursor));
    ui->textEdit->setPlainText(in.readAll());
    //���ָ�
    QApplication::restoreOverrideCursor();
    isUntitled =false;
    //��ȡ�ļ�·��
    curFilePath=QFileInfo(fileName).canonicalFilePath();
    setWindowTitle(curFilePath);
    return true;
 //�ú���ִ���������ļ�read����������Ĳ�����saveFile()���������Ƶġ�
}
MainWindow::~MainWindow()
{
    delete ui;
}



void MainWindow::on_action_O_triggered()//Open file
{
    if(isNeedSave()){
        QString fileName= QFileDialog::getOpenFileName(this);
        //if the fileName is not empty,then load the file
        if(!fileName.isEmpty()){
            loadFile(fileName);
            ui->textEdit->setVisible(true);
        }
    }
}

void MainWindow::on_action_C_triggered()//Close it
{
    if(isNeedSave()){

        ui->textEdit->setVisible(false);

    }
}


void MainWindow::on_action_Exit_triggered()
{
    on_action_C_triggered();
    //qApp is a global pointer
    //Quit
    qApp->quit();

}

void MainWindow::on_action_Z_triggered()
{
    ui->textEdit->undo();
}

void MainWindow::on_action_X_triggered()
{
     ui->textEdit->cut();
}

void MainWindow::on_action_C_2_triggered()
{
     ui->textEdit->copy();
}

void MainWindow::on_action_V_triggered()
{
    ui->textEdit->paste();
}


//���︴�ơ�ճ���ȳ��ù���QTextEdit�Ѿ�ʵ���ˣ�����ֻ��Ҫ������Ӧ�ĺ������ɡ���Ȼʵ�����˳����ܣ�����
//��ʱ���ʹ�ô��ڱ������Ĺرհ�ť���رճ�������������Ҫʹ�ùر��¼�����������ʵ����Ӧ�Ĺ��ܡ�
void MainWindow::showFindText()
{
    QString str = findLineEdit->text();
    ui->textEdit->find(str, QTextDocument::FindBackward);
    if (!ui->textEdit->find(str, QTextDocument::FindBackward))
    {
       QMessageBox::warning(this, tr("Failed!"),
                tr("can not find file %1").arg(str));
    }
}
void MainWindow::on_action_F_triggered()
{
    findDlg->show();
}
